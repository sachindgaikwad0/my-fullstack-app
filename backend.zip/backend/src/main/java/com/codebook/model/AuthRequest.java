package com.codebook.model;

import lombok.Data;

@Data
public class AuthRequest {

    public AuthRequest(){}

    private String  username;
    private String  password;

}
